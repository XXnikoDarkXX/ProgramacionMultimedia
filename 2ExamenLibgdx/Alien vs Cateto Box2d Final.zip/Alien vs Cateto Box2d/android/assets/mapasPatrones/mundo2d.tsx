<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="mundo2d" tilewidth="16" tileheight="16" tilecount="783" columns="29" backgroundcolor="#af3592">
 <image source="../texturas/Tiles.png" width="464" height="432"/>
</tileset>
