package pantallas;

import basedatos.BaseDatos;

public class Sembrao extends Pantalla {

    public Sembrao(BaseDatos bd){

        super("fondosPantalla/sembrao.png",bd);
    }

}
