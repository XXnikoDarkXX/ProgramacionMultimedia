# Unity Package Manager UI

[![](https://badges.cds.internal.unity3d.com/packages/com.unity.package-manager-ui/build-badge.svg?branch=2018.3%2Fstaging)](https://badges.cds.internal.unity3d.com/packages/com.unity.package-manager-ui/build-info?branch=2018.3%2Fstaging) [![](https://badges.cds.internal.unity3d.com/packages/com.unity.package-manager-ui/dependencies-badge.svg?branch=2018.3%2Fstaging)](https://badges.cds.internal.unity3d.com/packages/com.unity.package-manager-ui/dependencies-info?branch=2018.3%2Fstaging) [![](https://badges.cds.internal.unity3d.com/packages/com.unity.package-manager-ui/dependants-badge.svg)](https://badges.cds.internal.unity3d.com/packages/com.unity.package-manager-ui/dependants-info) ![ReleaseBadge](https://badges.cds.internal.unity3d.com/packages/com.unity.package-manager-ui/release-badge.svg) ![ReleaseBadge](https://badges.cds.internal.unity3d.com/packages/com.unity.package-manager-ui/candidates-badge.svg)

Unity Package Manager UI as a Unity Package
