package com.alerd.ejercicioexamen

import android.content.Context
import android.content.SharedPreferences
import android.content.res.ColorStateList
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import java.lang.Exception


abstract class Madre : AppCompatActivity() {

    //variable donde queremos guardar y cargar nuestro archivo xml preferencias
    lateinit var preferencias: SharedPreferences //Declaro preferencias


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    fun aplicarModoOscuro(){
        //getSharedPreferences -> Se inicializa las preferencias
        preferencias=this.getSharedPreferences("Preferencias", Context.MODE_PRIVATE)//nombe del archivo donde se guarda las preferencias y machacar

        //Establecemos valor inicial de la preferencias
        val modoOscuro: Boolean = preferencias.getBoolean("modoOscuro", false)//pares clave valor
        if (modoOscuro){

            val contenedorPrincipal: ViewGroup = findViewById<ViewGroup>(R.id.contenedorPrincipal)
            contenedorPrincipal.backgroundTintList = ColorStateList.valueOf(ResourcesCompat.getColor(resources, R.color.black, theme))

            ponerTextosClaros(findViewById(R.id.contenedorPrincipal))
        }
    }

    private  fun ponerTextosClaros(v: View){
        val viewGroup=v as ViewGroup
        for (i in 0 until viewGroup.childCount){
            val v1: View = viewGroup.getChildAt(i)
            if (v1 is ViewGroup){
                ponerTextosClaros(v1)
            }else{
                try {
                    //intento convertir a TextView
                    (v1 as TextView).setTextColor(ContextCompat.getColor(this,R.color.white))
                }catch (e: Exception){
                    //si falla, no hago nada y continuo el programa.Simplemente esa vista no era un textview
                }
            }

        }
    }

}