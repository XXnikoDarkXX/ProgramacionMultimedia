<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="tileset_basic_terrain" tilewidth="16" tileheight="16" tilecount="528" columns="12">
 <image source="../texturas/tileset_basic_terrain.png" width="192" height="704"/>
</tileset>
