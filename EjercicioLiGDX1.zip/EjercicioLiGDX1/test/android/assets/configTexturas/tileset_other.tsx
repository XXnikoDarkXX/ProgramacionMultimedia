<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="tileset_other" tilewidth="16" tileheight="16" tilecount="736" columns="23">
 <image source="../texturas/tileset_other.png" width="368" height="512"/>
</tileset>
