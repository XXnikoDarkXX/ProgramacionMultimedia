<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="tileset_water" tilewidth="16" tileheight="16" tilecount="915" columns="15">
 <image source="../texturas/tileset_water.png" width="240" height="976"/>
</tileset>
