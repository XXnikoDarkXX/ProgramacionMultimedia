# LSEDactilologico-CENEC
Programa para traducir el castellano escrito al LSE Dactilológico, programado por los alumnos de CENEC Málaga
