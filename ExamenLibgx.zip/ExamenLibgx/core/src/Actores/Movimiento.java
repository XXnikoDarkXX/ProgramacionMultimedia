package Actores;

import com.badlogic.gdx.scenes.scene2d.InputListener;

public enum Movimiento {
    GIRO


}
