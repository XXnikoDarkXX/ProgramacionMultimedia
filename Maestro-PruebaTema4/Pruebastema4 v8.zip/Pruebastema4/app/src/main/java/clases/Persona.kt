package clases

class Persona(val nombre:String,val imagenURl:String) {

}