package com.nicolasfernandez.pruebatema4

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Toast.makeText(this, "onCreate", Toast.LENGTH_LONG).show()
        this.getDrawable(R.drawable.ic_launcher_foreground)

        var botonAñadir:Button=findViewById(R.id.botonAniadir)
        botonAñadir.setOnClickListener{
            vista:View->
            var contenedor:LinearLayout= this.findViewById<LinearLayout>(R.id.contenedor)
            var nuevo:Button= Button(this)
            nuevo.setText(R.string.botonAniadido)
            contenedor.addView(nuevo)


        }
    }
    //al iniciar  la aplicacion
    override fun onStart() {
        super.onStart()
        Toast.makeText(this, "onStart", Toast.LENGTH_LONG).show()

    }
    //te pone de nuevo en donde estabas en la app
    override fun onResume() {
        super.onResume()
        Toast.makeText(this, "onResume", Toast.LENGTH_LONG).show()

    }

    /**
     * Esto pone cuando minimas y abres la aplicacion
     */
    override fun onPause() {
        super.onPause()
        Toast.makeText(this, "onPause", Toast.LENGTH_LONG).show()

    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Destruyendo", "destruyendo")
        Toast.makeText(this, "onDestroy", Toast.LENGTH_LONG).show()

    }
    //reinicia la app
    override fun onRestart() {
        super.onRestart()
        Toast.makeText(applicationContext, "onRestart", Toast.LENGTH_LONG).show()

    }

    fun siguienteActividad(view: View) {
        var pasarActividad: Intent=Intent(this,Pantalla2::class.java)//Guardamos la pantalla2 como tipo Intent
        //que sirve para realizar una accion
        this.startActivity(pasarActividad)//Sirve para lanzar la actividad y se ejecute luego todo el proceso

        var bundle:Bundle=Bundle()
        var campoTexti:EditText=findViewById<EditText>(R.id.campoTexto)
        var campoNumero:EditText=findViewById<EditText>(R.id.CampoNumero)

        //bundle.putString("info1",""+campoTexto.text)//forma irrgular
        bundle.putString("info1",campoTexti.text.toString())


        bundle.putShort("short1",campoNumero.text.toString().toShort())
        pasarActividad.putExtras(bundle)
        this.startActivity(pasarActividad)




    }


}