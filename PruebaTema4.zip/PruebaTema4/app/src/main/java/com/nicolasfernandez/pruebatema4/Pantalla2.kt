package com.nicolasfernandez.pruebatema4

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView

class Pantalla2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pantalla2)
        var bundle:Bundle?=this.intent.extras
        var info1:String?=bundle?.getString("info1")
        var short1:Short?=bundle?.getShort("short1")
        var textoCentral:TextView=findViewById<TextView>(R.id.textoCentral)
        textoCentral.setText(info1+" : "+short1)
    }

    fun irPantalla3(view: View) {

        var pasarActividad3: Intent =Intent(this,Pantalla3::class.java)//creamos una variable de tipo Intent(Activida)
        //de pantalla3
        this.startActivity(pasarActividad3)

    }
}