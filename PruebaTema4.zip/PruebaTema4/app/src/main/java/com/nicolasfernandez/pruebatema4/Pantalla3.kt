package com.nicolasfernandez.pruebatema4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Pantalla3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pantalla3)
    }
}