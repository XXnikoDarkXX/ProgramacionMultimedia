package clases

class Usuario(val id:Int, var nombre:String,var contraseña:String) {

}