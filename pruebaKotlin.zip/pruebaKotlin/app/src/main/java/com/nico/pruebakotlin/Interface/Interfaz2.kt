package com.nico.pruebakotlin.Interface

interface Interfaz2 {
    fun prueba1 ( arg1:String,  arg2:Float)


}