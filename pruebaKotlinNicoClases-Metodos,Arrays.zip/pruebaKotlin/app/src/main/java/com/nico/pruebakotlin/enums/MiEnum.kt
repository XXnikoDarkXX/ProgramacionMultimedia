package com.nico.pruebakotlin.enums

enum class MiEnum {
    UNO,
    DOS,
    TRES
}