package com.nico.pruebakotlin.excepciones

class MiExcepcion(msg:String):Exception(msg) {
}