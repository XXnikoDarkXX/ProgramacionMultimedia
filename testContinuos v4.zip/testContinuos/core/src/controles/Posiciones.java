package controles;

public enum Posiciones {
    ARRIBA,
    ABAJO,
    IZQUIERDA,
    DERECHA
}
