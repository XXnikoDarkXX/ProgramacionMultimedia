package pantallas;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

import java.util.ArrayList;
import java.util.Random;

import personajes.Alien;
import personajes.Objeto;

public abstract class Pantalla extends Stage {
    private ScreenViewport camara; //Cámara
    private ArrayList<Objeto> jugadores; //Personajes que controlo
    private ArrayList<Objeto> npc; //Personajes que no controlo
    private SpriteBatch batch; //De momento, solo para dibujar fondo
    private Texture fondo; //Textura del fondo de pantalla
    private int jugadorConFoco; //Que jugador tiene el foco de teclado
    private int npcConFoco; //Qué cateto tiene el foco
    private World mundo; //Mundo de Box2D para aplicar físicas
    private OrthogonalTiledMapRenderer renderer; //Renderizador del mapa.
    private static float unitScale=1/16f; //Depende del ancho de pixels de los patrones del mapa
    private TiledMap mapa; //Mapa 2D de la pantalla actual

    public Pantalla(String rutaFondo){
        super(new ScreenViewport());
        camara=(ScreenViewport)this.getViewport();
        jugadores=new ArrayList<Objeto>();
        npc=new ArrayList<Objeto>();
        batch=new SpriteBatch();
        fondo=new Texture(rutaFondo);
        Gdx.input.setInputProcessor(this);
        mundo=new World(new Vector2(0,-9.8f),true);
        mapa=new TmxMapLoader().load("mapas/pantalla2D.tmx");
        renderer=new OrthogonalTiledMapRenderer(mapa,unitScale);
    }

    public World getMundo(){
        return mundo;
    }

    @Override
    public void draw() {
        mundo.step(Gdx.graphics.getDeltaTime(),
                6,2);
        batch.begin();
        batch.draw(fondo,0,0, Gdx.graphics.getWidth(),
                Gdx.graphics.getHeight());
       // Gdx.app.log("tamañoPantalla",Gdx.graphics.getWidth()+" x "+Gdx.graphics.getHeight());
        batch.end();
        getCamera().position.x=this.jugadores.get(jugadorConFoco).getX();
        getCamera().position.y=this.jugadores.get(jugadorConFoco).getY();
        renderer.setView(camara);
        camara.update(10,10);
        super.draw();
    }

    public void resize(int ancho,int alto){
        camara.update(ancho,alto);
    }

    public void añadirJugador(Objeto o){
        this.addActor(o);
        this.jugadores.add(o);
    }

    public void añadirNPC(Objeto o){
        this.addActor(o);
        this.npc.add(o);
    }

    public void ponerFocoControl(Objeto o){
        //una de las dos: jugadorConFoco o npcConFoco, me va a dar -1
        //porque el objeto solo está en uno de los dos arrays
        this.jugadorConFoco=jugadores.indexOf(o);
        this.npcConFoco=npc.indexOf(o);
        this.setKeyboardFocus(o);
    }

    public void focoAlSiguiente(){
        if(jugadorConFoco!=-1) { //Si estoy con el foco en jugadores
            jugadores.get(jugadorConFoco).limpiarMovimiento();
            jugadorConFoco++;
            if(jugadorConFoco==jugadores.size()){
                jugadorConFoco=0;
            }
            this.setKeyboardFocus(jugadores.get(jugadorConFoco));
        }else{ //El foco está en el array de catetos
            npc.get(npcConFoco).limpiarMovimiento();
            this.npcConFoco++;
            if(npcConFoco==npc.size()){
                npcConFoco=0;
            }
            this.setKeyboardFocus(npc.get(npcConFoco));
        }
    }

    public Objeto getJugador(int index){
        return this.jugadores.get(index);
    }

    public Objeto getNPC(int index){
        return this.npc.get(index);
    }

    public void generarAlien(){
        Random r=new Random();
        //Elijo pos aleatoria en x e y
        int posX=r.nextInt(10);
        int posY=r.nextInt(10)+10;
        Alien nuevo=new Alien(this,posX,posY);
        jugadores.add(nuevo);
        Gdx.app.log("zIndex Alien",""+nuevo.getZIndex());
        this.addActor(jugadores.get(jugadores.size()-1));
    }

    public void dispose(){
        mundo.dispose();
        this.dispose();
    }



}
