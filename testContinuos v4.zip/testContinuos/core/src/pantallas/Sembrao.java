package pantallas;

import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class Sembrao extends Pantalla {

    public Sembrao(){

        super("fondosPantalla/sembrao.png");
    }

}
